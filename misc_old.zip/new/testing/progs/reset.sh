#!/bin/bash

cd stockpile
rm -r *
cd ..
